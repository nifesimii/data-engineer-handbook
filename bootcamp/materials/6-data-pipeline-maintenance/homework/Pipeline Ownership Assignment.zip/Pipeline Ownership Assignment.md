﻿**Pipeline Ownership Assignment**

**Pipelines and Responsibilities**

1. **Unit-Level Profit for Experiments (Profit)**
   1. **Primary Owner**: Nifesimi
   1. **Secondary Owner**: Ivan
1. **Aggregate Profit Reported to Investors (Profit)**
   1. **Primary Owner**: Zach
   1. **Secondary Owner**: Rahul
1. **Aggregate Growth Reported to Investors (Growth)**
   1. **Primary Owner**: Rahul
   1. **Secondary Owner**: Nifesimi
1. **Daily Growth Needed for Experiments (Growth)**
   1. **Primary Owner**: Ivan
   1. **Secondary Owner**: Zach
1. **Aggregate Engagement Reported to Investors (Engagement)**
   1. **Primary Owner**: Nifesimi
   1. **Secondary Owner**: Zach
-----
**On-Call Schedule**

1. **Rotational Schedule**:
   1. Rotate on-call responsibilities weekly to ensure fairness.
   1. Assign each team member to one week of on-call duty every four weeks.
1. **Holiday Coverage**:
   1. Create a holiday exception plan where:
      1. Each person has the opportunity to swap shifts for planned holidays.
      1. If someone is unavailable during their assigned holiday week, the secondary owner covers the responsibility.
1. **Example Schedule**:

   |**Week**|**On-Call Engineer**|**Back-Up Engineer**|
   | :-: | :-: | :-: |
   |1|Nifesimi|Ivan|
   |2|Zach|Rahul|
   |3|Ivan|Zach|
   |4|Rahul|Nifesimi|

-----
**Run Books for Investor-Reported Metrics**

Each run book should include:

1. **Pipeline Overview**:
   1. Purpose of the pipeline.
   1. Key metrics it calculates.
1. **Data Sources**:
   1. Input datasets and dependencies.
1. **Pipeline Steps**:
   1. ETL stages (Extraction, Transformation, Loading).
   1. Scheduled jobs and their triggers.
1. **Failure Scenarios**:
   1. Common points of failure and their indicators.
1. **Alerts**:
   1. Notifications for pipeline failures or degraded performance.
1. **Resolution Steps**:
   1. Step-by-step troubleshooting guide.
   1. Contacts for additional support.
-----
**Potential Pipeline Issues**

1. **Unit-Level Profit Pipeline (Experiments)**
   1. **Issues**:
      1. Errors in profit computation logic leading to skewed results.
      1. Delayed data ingestion impacting experimental decisions.
1. **Aggregate Profit Pipeline (Investors)**
   1. **Issues**:
      1. Data duplication causing over-reported profits.
      1. Loss of investor trust due to delayed reporting.
1. **Aggregate Growth Pipeline (Investors)**
   1. **Issues**:
      1. Mismatch in growth metrics from upstream datasets.
      1. Seasonal data fluctuations misinterpreted as errors.
1. **Daily Growth Pipeline (Experiments)**
   1. **Issues**:
      1. Inconsistent data refresh times causing partial updates.
      1. Experiment results misaligned with growth trends.
1. **Aggregate Engagement Pipeline (Investors)**
   1. **Issues**:
      1. Incorrect handling of outliers leading to unrealistic engagement metrics.
      1. API timeouts when querying external systems for engagement data.

